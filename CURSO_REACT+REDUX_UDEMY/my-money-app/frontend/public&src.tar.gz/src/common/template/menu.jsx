import React from "react";

export default (props) => <ul className="sidebar-menu"></ul>;
