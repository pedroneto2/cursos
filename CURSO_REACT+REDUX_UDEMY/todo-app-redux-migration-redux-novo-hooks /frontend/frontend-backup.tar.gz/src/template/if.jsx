export default (props) => (props.test ? null : props.children);
