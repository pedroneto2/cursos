import React from "react";
import PageHeader from "../template/pageHeader";

export default (props) => (
  <div>
    <PageHeader name="Sobre" small="Nos" />
    <h1>Nossa Historia</h1>
    <p>Lorem ipsum sei la o que, sei la o que...</p>
    <h2>Nossa Missao</h2>
    <p>Lorem ipsum sei la o que, sei la o que...</p>
    <h3>Imprensa</h3>
    <p>De novo essa de lorem ipsum sei la o que....</p>
  </div>
);
